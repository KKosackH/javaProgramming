package afleveringsopgave2;
import java.util.Scanner;

public class Palindrome {

	
	static void converter(String line) {
		
		//Makes empty char array to store the char from the console input
		char[] invLine = new char[line.length()];

		//Loops from i, which is set as equal to the length of the line -1 until 0
		for (int i = line.length()-1; i > -1 ; i--) {
			
		//Inverts the console input and store it as a char array.
			invLine[line.length()-i-1] = line.charAt(i);
			
			}
		
		// Converts the char array to a string and replace all characters which are not letters. Also sets the whole string as lowercase.
		String invString = new String(invLine).replaceAll("[^a-zA-Z]", "").toLowerCase();
		String lineString = line.replaceAll("[^a-zA-Z]", "").toLowerCase();
		
		// If statement for printing out if the string is a palindrome
		if (invString.equals(lineString)) {
			System.out.println("\""+ line + "\"" + " is a palindrome!");
			} else {
			System.out.println("\""+ line + "\"" + " is not a palindrome!");
			}
		}
			
	public static void main(String[] args) {
		
		// Prints the text, get the input from the console and run the function
		System.out.print("Enter line to check: ");
		Scanner console = new Scanner(System.in);
		
		String line = console.nextLine();
		converter(line);
	}
	
		
}
