module afleveringsopgave2 {
}