package afleveringsopgave3;

import java.util.Scanner;

public class RaceTrack2 {
	
	static void playerMove(double in1[], double in2[], int playerChoice) {
		switch(playerChoice) {
		
		case 1:
			in1[0] = -1;
			in1[1] = -1;
			break;
			
		case 2:
			in1[0] = 0;
			in1[1] = -1;
			break;
			
		case 3:
			in1[0] = 1;
			in1[1] = -1;
			break;
			
		case 4:
			in1[0] = -1;
			in1[1] = 0;
			break;
			
		case 5:
			in1[0] = 0;
			in1[1] = 0;
			break;
			
		case 6:
			in1[0] = 1;
			in1[1] = 0;
			break;
			
		case 7:
			in1[0] = -1;
			in1[1] = 1;
			break;
			
		case 8:
			in1[0] = 0;
			in1[1] = 1;
			break;
			
		case 9:
			in1[0] = 1;
			in1[1] = 1;
			break;			
			
		}
		
	}
	
	static void track() {
		
	}
	
	static void crashDet(double startvalx, double startvaly) {
		
		if(startvalx <= 0 || startvalx >= 20 || startvaly <= 0 || startvaly >= 20){
			
			System.out.println("The car has crashed, press restart to try again");
			
		}
		
	}
	
	public static void main(String[] args) {
		
		track();
		
		Scanner console = new Scanner(System.in);
		
		double in1[] = new double[2];
		double in2[] = new double[2];
		int playerChoice = 0;
		
		double startvalx = 10;
		double startvaly = 10;
		
		while(true){
			
			if(console.hasNextInt()) {
				
				playerChoice = console.nextInt();
				
				if(playerChoice < 10 && playerChoice > 0) {
					
					playerMove(in1,in2,playerChoice);
					
					startvalx = startvalx + in1[0] + in2[0];
					startvaly = startvaly + in1[1] + in2[1];

					in2[0] = in1[0] + in2[0];
					in2[1] = in1[1] + in2[1];
					
					System.out.println(startvalx);
					System.out.println(startvaly);
					
				}
			}
		}		
	}
}