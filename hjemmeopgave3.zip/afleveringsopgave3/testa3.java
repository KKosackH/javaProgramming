package afleveringsopgave3;

import java.lang.Math;

public class testa3 {
	public static void main(String[] args) {
		double startvalxlastbot = 5;
		double startvalxbot = 2;
		double startvalylastbot = 7;
		double startvalybot = 9;
		double lengVector = Math.sqrt(Math.pow(startvalxlastbot-startvalxbot,2)+Math.pow(startvalylastbot-startvalybot,2));	
		System.out.println(lengVector);
	}
}
