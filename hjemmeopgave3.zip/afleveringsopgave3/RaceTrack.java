package afleveringsopgave3;

import edu.princeton.cs.introcs.*;
import java.lang.Math;
import java.util.Scanner;
import java.util.Random;

public class RaceTrack {
	
	static void track() {
		
		//Sets the scale of the track, so that each square is 1/400 of the track
		StdDraw.setXscale(0,20);
		StdDraw.setYscale(0,20);
		StdDraw.setPenColor(StdDraw.LIGHT_GRAY);
		
		StdDraw.picture(10,10,"udklip.PNG",10,10);

		//Paints the track the player is allowed to move on grey
		StdDraw.filledRectangle(10, 0, 20, 5);
		StdDraw.filledRectangle(0, 10, 5, 20);
		StdDraw.filledRectangle(17.5, 10, 2.5, 20);
		StdDraw.filledRectangle(10, 17.5, 5, 2.5);
		StdDraw.setPenColor(StdDraw.BLACK);
		
		//Paints the lines which the player moves to
		for(int i = 0; i <= 20; i++) {
			if(i <= 5 || i >= 15) {
			StdDraw.line(0,i,20,i);
			StdDraw.line(i, 0, i, 20);
			}else {
			StdDraw.line(i, 0, i, 5);
			StdDraw.line(0, i, 5, i);
			StdDraw.line(i, 20, i, 15);
			StdDraw.line(20, i, 15, i);
			}
		}
		
		//Draws the outlines of the track, the finish and checkpoint line and the start position of the player

		StdDraw.setPenRadius(0.01);
		StdDraw.square(10,10,5);
		StdDraw.square(10,10,10);
		StdDraw.setPenColor(StdDraw.GREEN);
		StdDraw.line(10, 15, 10, 20);
		StdDraw.setPenColor(StdDraw.BLUE);
		StdDraw.line(10,0,10,5);
		StdDraw.setPenColor(StdDraw.BLACK);
		StdDraw.filledCircle(10,18,0.2);
		StdDraw.filledCircle(10, 16, 0.2);
		StdDraw.setPenRadius(0.0025);
	}
	//Draws the players next position and connecting the last position with the new position with a wire
	static void gameFunc(double startvalx, double startvaly, double startvalxlast, double startvalylast) {

		StdDraw.setPenColor(StdDraw.RED);
		StdDraw.setPenRadius(0.01);
		StdDraw.line(startvalxlast, startvalylast, startvalx, startvaly);
		
		StdDraw.setPenColor(StdDraw.BLACK);
		StdDraw.filledCircle(startvalx, startvaly, 0.2);
	}
	//Same as above, just with other colors
	static void gameFunc2(double startvalx, double startvaly, double startvalxlast, double startvalylast) {

		StdDraw.setPenColor(StdDraw.PINK);
		StdDraw.setPenRadius(0.01);
		StdDraw.line(startvalxlast, startvalylast, startvalx, startvaly);
		
		StdDraw.setPenColor(StdDraw.BLACK);
		StdDraw.filledCircle(startvalx, startvaly, 0.2);
	}
	
	//This is the vector direction the player can choose, where the first is the x-coordinate, and the second is the y-coordinate
	static void playerMove(double in1[], double in2[], int playerChoice) {
		switch(playerChoice) {
		
		case 1:
			in1[0] = -1;
			in1[1] = -1;
			break;
			
		case 2:
			in1[0] = 0;
			in1[1] = -1;
			break;
			
		case 3:
			in1[0] = 1;
			in1[1] = -1;
			break;
			
		case 4:
			in1[0] = -1;
			in1[1] = 0;
			break;
			
		case 5:
			in1[0] = 0;
			in1[1] = 0;
			break;
			
		case 6:
			in1[0] = 1;
			in1[1] = 0;
			break;
			
		case 7:
			in1[0] = -1;
			in1[1] = 1;
			break;
			
		case 8:
			in1[0] = 0;
			in1[1] = 1;
			break;
			
		case 9:
			in1[0] = 1;
			in1[1] = 1;
			break;			
			
		}
		
	}
	
	//This method checks if the player has crashed, if they players have crashed together, if they cross the checkpoint, if they cross the finish line
	//and if they go the opposite direction. The method also returns the value cpReached and crash, which will ocur if they crash or cross the
	// checkpoint
	static int[] crashDet(double startvalx, double startvaly,double startvalxlast, double startvalylast, int cpReached, int playerMoves, int crash, int playerNr) {
		
		double cornerDetx;
		double cornerDety;
		
		
		if(startvalx <= 0 || startvalx >= 20 || startvaly <= 0 || startvaly >= 20 ||  (startvalx >= 5 && startvalx <= 15) && (startvaly >= 5 && startvaly <= 15)){
			StdDraw.text(10, 10, "GAME OVER");
			System.out.println("Player " + playerNr + " has crashed, press restart to try again");
			crash = 1;
		}
		if(startvalxlast > 10 && startvalylast < 5) {
			if(startvalx < 10 && startvaly < 5) {
				System.out.println("Congratulations player " + playerNr + " just passed the checkpoint");
				cpReached = 1;
			}
		}
		if(cpReached == 1 && startvalxlast < 10 && startvalylast < 5) {
			if(startvalx > 10 && startvaly < 6) {
				System.out.println("WRONG WAY " + playerNr + " TURN AROUND");
				cpReached = 0;
			}
		}
		if(cpReached == 1 && startvalxlast < 10 && startvalylast > 15) {
			if(startvalx > 10 && startvaly > 15) {
				System.out.println("Congratulations, you just passed the finish line");
				StdDraw.text(10, 10,"Player" + playerNr + "won in " + playerMoves + "moves");
			}
		}
		
		for(double c = 1; c <= 10; c++) {
			cornerDetx = (startvalx*(c/10))-(startvalxlast*(c/10))+startvalxlast;
			cornerDety = (startvaly*(c/10))-(startvalylast*(c/10))+startvalylast;
			if((cornerDetx <= 15 && cornerDetx >= 5) && (cornerDety <= 15 && cornerDety >= 5)) {
				StdDraw.text(10, 10, "GAME OVER");
				//System.out.println("THE CAR HAS CRASHED");
				crash = 1;
				break;
			}
		}
		return new int[] {cpReached,crash};
	}
	
	//THE CODE BELOW HAS NOT BEEN FINISHED
	//The code below was for the bot movement, but has not been finished yet
	static int bot(int botChoice, Random ran, double startvalxbot, double startvalybot, double startvalxlastbot, double startvalylastbot, double lengVector, int cpReachedbot, int playerMovesbot, int crash, double inbot1[], double inbot2[], int playerbot) {
		
		int botChoiceRight[] = {3,6,9};
		int botChoiceDown[] = {1,2,3};
		int botChoiceLeft[] = {4,6,8};
		int botChoiceUp[] = {7,8,9};
		int randomVal;
		int botChoiceTemp;
		double startvalxbotTemp = 10;
		double startvalybotTemp = 16;
		double inbot1Temp[] = new double[2];
		double inbot2Temp[] = new double[2];
		double startvalxlastbotTemp = 10;
		double startvalylastbotTemp = 16;
		int playerMovesbotTemp = 1;
		int cpReachedbotTemp = 0;
		
			if(startvalxbot > 7 && startvalxbot < 13 && startvalybot > 15){ //Straight top
				for(;;) {
					randomVal = ran.nextInt(botChoiceRight.length);
					botChoiceTemp = botChoiceRight[randomVal];
					
					playerMove(inbot1Temp,inbot2Temp,botChoiceTemp);
					
					startvalxbotTemp = startvalxbotTemp + inbot1Temp[0] + inbot2Temp[0];
					startvalybotTemp = startvalybotTemp + inbot1Temp[1] + inbot2Temp[1];

					
					inbot2Temp[0] = inbot1Temp[0] + inbot2Temp[0];
					inbot2Temp[1] = inbot1Temp[1] + inbot2Temp[1];
					
					int crashDatabot[] = crashDet(startvalxbotTemp,startvalybotTemp,startvalxlastbotTemp,startvalylastbotTemp, cpReachedbotTemp, playerMovesbotTemp, crash, playerbot);
					if(crashDatabot[1] != 1) {
						botChoice = botChoiceTemp;
						break;
					}else {
						startvalxbotTemp = startvalxlastbotTemp;
						startvalybotTemp = startvalylastbotTemp;
					}
					startvalxlastbotTemp = startvalxbotTemp;
					startvalylastbotTemp = startvalybotTemp;
					playerMovesbotTemp++;
				}
			}else if(startvalxbot > 13 && startvalxbot < 20 && startvalybot > 12){ //Right top corner
				randomVal = ran.nextInt(botChoiceDown.length);
				botChoice = botChoiceDown[randomVal];
				
			}else if(startvalxbot > 15 && startvalxbot < 20 && startvalybot < 13 && startvalybot > 7){ //straight right
				randomVal = ran.nextInt(botChoiceDown.length);
				botChoice = botChoiceDown[randomVal];
			}else if(startvalxbot > 13 && startvalxbot < 20 && startvalybot < 7 && startvalybot > 0) { //Right bottom corner
				randomVal = ran.nextInt(botChoiceLeft.length);
				botChoice = botChoiceLeft[randomVal];
			}else if(startvalxbot > 7 && startvalxbot < 13 && startvalybot < 5 && startvalybot > 0) { // Bottom straight
				randomVal = ran.nextInt(botChoiceLeft.length);
				botChoice = botChoiceLeft[randomVal];
			}else if(startvalxbot > 0 && startvalxbot < 8 && startvalybot < 8 && startvalybot > 0) { //Left bottom corner
				randomVal = ran.nextInt(botChoiceUp.length);
				botChoice = botChoiceUp[randomVal];
			}else if(startvalxbot > 0 && startvalxbot < 6 && startvalybot > 6 && startvalybot < 14) { //Left straight
				randomVal = ran.nextInt(botChoiceUp.length);
				botChoice = botChoiceUp[randomVal];
			}else if(startvalxbot > 0 && startvalxbot < 8 && startvalybot > 12 && startvalybot < 20) { //Left top corner
				randomVal = ran.nextInt(botChoiceRight.length);
				botChoice = botChoiceRight[randomVal];
		}

		return botChoice;
	}
	
	public static void main(String[] args) {
		
		//Initialization
		track();
		Scanner console = new Scanner(System.in);
		Random ran = new Random();
		
		int crash = 0;
		
		int playerGamemode = 0;
		
		//Initialization bot
		double inbot1[] = new double[2];
		double inbot2[] = new double[2];
		
		int botChoice = 0;
		int playerbot = 0;
		int cpReachedbot = 0;
		
		double startvalxbot = 10;
		double startvalybot = 16;
		
		double startvalxlastbot = 10;
		double startvalylastbot = 16;
		
		int playerMovesbot = 1;
		
		//Initialization player 1
		double in1[] = new double[2];
		double in2[] = new double[2];
		
		int playerChoice = 0;
		int playerNumber = 1;
		int cpReached = 0;

		double startvalx = 10;
		double startvaly = 18;
		
		double startvalxlast = 10;
		double startvalylast = 18;
		
		int playerMoves = 1;
		
		//Initialization player 2
		double in3[] = new double[2];
		double in4[] = new double[2];
		
		int playerChoice2 = 0;
		int playerNumber1 = 2;
		int cpReached2 = 0;

		double startvalx2 = 10;
		double startvaly2 = 16;
		
		double startvalxlast2 = 10;
		double startvalylast2 = 16;	
		
		int playerMoves2 = 1;

		System.out.println("Press 10 and continue with enter if you want to play with a bot");
		System.out.println("Otherwise press a random key and continue with enter");
		System.out.println("To make a move, enter a number between 1-9");
		System.out.println("Both players need to enter a number before the move will be made");
		
		//This was meant to be used for the bot, to make sure the bot would not crash and is the length of the vector from the last point
		//to the new point
		double lengVector = 0;
		
		//Checks for integer as userinput
		for(;;) {
			if(console.hasNextInt()) {
				playerGamemode = console.nextInt();
				break;
			}
		}
		
		for(;;) {
				
			//If userinput was 10, the code below will run
			
			if(playerGamemode == 10) {
				
				System.out.println("You will now play against a bot");
				
				for(;;) {
					//Has not been finished, but this was the botMovement
					botChoice = bot(botChoice, ran, startvalxbot, startvalylastbot, startvalxbot, startvalylastbot, lengVector, cpReachedbot, playerMovesbot, crash, inbot1,inbot2, playerbot);
					
					//The players direction choice
					playerChoice = console.nextInt();
					System.out.println(botChoice);
					
					//This if statement makes sure, the player have chosen an input between 1-9
					if(playerChoice < 10 && playerChoice > 0) {
						
						//This is the method, taking int the inputs, and moving the current position of the player
						playerMove(in1,in2,playerChoice);
						playerMove(inbot1,inbot2,botChoice);
						
						//The lines 345-349 is the actual calculation of the vectors, where it just adds the player input to the current value
						startvalx = startvalx + in1[0] + in2[0];
						startvaly = startvaly + in1[1] + in2[1];

						in2[0] = in1[0] + in2[0];
						in2[1] = in1[1] + in2[1];
						
						//Same as above, just for the bot
						startvalxbot = startvalxbot + inbot1[0] + inbot2[0];
						startvalybot = startvalybot + inbot1[1] + inbot2[1];
						
						inbot2[0] = inbot1[0] + inbot2[0];
						inbot2[1] = inbot1[1] + inbot2[1];
						
						//Draws the playermovement as explained earlier
						gameFunc(startvalx,startvaly,startvalxlast,startvalylast);
						
						//This detects for crashes and if the checkpoint is reached
						int crashData[] = crashDet(startvalx,startvaly,startvalxlast,startvalylast, cpReached, playerMoves, crash, playerNumber);
						cpReached = crashData[0];
						
						//Same as above
						gameFunc2(startvalxbot, startvalybot, startvalxlastbot, startvalylastbot);
						int crashData2[] = crashDet(startvalxbot, startvalybot, startvalxlastbot, startvalylastbot, cpReachedbot, playerMovesbot, crash, playerbot);
						cpReachedbot = crashData2[0];
						
						//This is not being used, but was for the bot, so it could not make the vector too long
						lengVector = Math.sqrt(Math.pow(startvalxlastbot-startvalxbot,2)+Math.pow(startvalylastbot-startvalybot,2));
						System.out.println("This is the length of the vector " + lengVector);
						
						//Sets the last position of the player as the new, so that it will now count from here
						startvalxlast = startvalx;
						startvalylast = startvaly;
						playerMoves++;
							
						//Same as above
						startvalxlastbot = startvalxbot;
						startvalylastbot = startvalybot;
						playerMovesbot++;
						
						//Prints if the player has crashed together
						if(startvalx == startvalx2 && startvaly == startvaly2) {
							StdDraw.text(10, 10, "GAME OVER");
							System.out.println("The cars has crashed together, press restart to try again");
						}
						
						//Prints the current position of the players
						System.out.println("Player 1(x):" + startvalx);
						System.out.println("Player 1(y):" + startvaly);		
							
						System.out.println("Player 2(x):" + startvalxbot);
						System.out.println("Player 2(y):" + startvalybot);	
							
					}
				}
			}
			
			//This has all been explained earlier, as this is just a copy of the game function above, now just with 2 players instead of a bot
			playerChoice = console.nextInt();
			playerChoice2 = console.nextInt();
				
			if(playerChoice < 10 && playerChoice > 0) {
					
				playerMove(in1,in2,playerChoice);
					
				playerMove(in3,in4,playerChoice2);
					
				startvalx = startvalx + in1[0] + in2[0];
				startvaly = startvaly + in1[1] + in2[1];

				in2[0] = in1[0] + in2[0];
				in2[1] = in1[1] + in2[1];
					
				startvalx2 = startvalx2 + in3[0] + in4[0];
				startvaly2 = startvaly2 + in3[1] + in4[1];

				in4[0] = in3[0] + in4[0];
				in4[1] = in3[1] + in4[1];
					
				gameFunc(startvalx,startvaly,startvalxlast,startvalylast);
				int crashDatap1[] = crashDet(startvalx,startvaly,startvalxlast,startvalylast, cpReached, playerMoves, crash, playerNumber);
				cpReached = crashDatap1[0];
					
				gameFunc2(startvalx2, startvaly2, startvalxlast2, startvalylast2);
				int crashDatap2[] = crashDet(startvalx2, startvaly2, startvalxlast2, startvalylast2, cpReached2, playerMoves2, crash, playerNumber1);
				cpReached2 = crashDatap2[0];
					
				startvalxlast = startvalx;
				startvalylast = startvaly;
				playerMoves++;
					
				startvalxlast2 = startvalx2;
				startvalylast2 = startvaly2;
				playerMoves2++;
					
				if(startvalx == startvalx2 && startvaly == startvaly2) {
					StdDraw.text(10, 10, "GAME OVER");
					System.out.println("The cars has crashed together, press restart to try again");
				}
					
				System.out.println("Player 1(x):" + startvalx);
				System.out.println("Player 1(y):" + startvaly);		
				
				System.out.println("Player 2(x):" + startvalx2);
				System.out.println("Player 2(y):" +startvaly2);		
			}
		}
	}
}
