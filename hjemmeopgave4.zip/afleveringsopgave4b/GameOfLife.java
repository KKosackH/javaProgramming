package afleveringsopgave4b;

import edu.princeton.cs.introcs.StdDraw;
import java.io.*;
import java.util.Scanner;
import java.lang.Math;

public class GameOfLife {
	
	//initialization of the map, and making the start dots in stddraw. The function returns this map array
	static int[][] mapInit(int[][] startArr) {
		
		int[][] mapArr = new int[502][502];
		
		for(int k = 0; k < startArr[0].length	; k++) {
			
			for(int h = 0; h < startArr[1].length; h++) {
				
				mapArr[k+1][h+1] = startArr[k][h];
				
				if(mapArr[k+1][h+1] == 1) {
					
					StdDraw.filledCircle(h+1,k+1, 0.5);
					
				}
			}
		}
		StdDraw.show(100);
		return mapArr;
	}
	
	//Function for counting neighbors, and deciding wether or not the next state is a 1 or 0. The function also returns the nextState array
	static int[][] nextState(int[][] startArr) {
		
		int[][] nextState = new int[502][502];
		StdDraw.clear();

		for(int k = 1; k < nextState[0].length-1; k++) {
			
			for(int h = 1; h < nextState[1].length-1; h++) {
				
				//Checks all 8 positions around the dot, so that we know if it will be dead or alive in next state.
				int neighbourAmmount = startArr[k-1][h-1] + startArr[k][h-1] + startArr[k-1][h] + startArr[k+1][h] + startArr[k][h+1] + startArr[k+1][h+1] + startArr[k-1][h+1] + startArr[k+1][h-1];
				
				if((neighbourAmmount == 2 || neighbourAmmount == 3) && startArr[k][h] == 1) {
					nextState[k][h] = 1;
					StdDraw.filledCircle(h, k, 0.5);
				}

				if(neighbourAmmount == 3 && nextState[k][h] == 0) {
					nextState[k][h] = 1;
					StdDraw.filledCircle(h, k, 0.5);
				}
				
			}
			
		}
		
		StdDraw.show(100);
		return nextState; 
	}
	
	public static void main(String[] args) throws FileNotFoundException{
		
		//Make a new scanner, reading from a certain file
		StdDraw.setXscale(0,200);
		StdDraw.setYscale(200,0);
		Scanner input = new Scanner(new File("glider_gun.gol"));
		
		//initialization
		int sizeArray = 0;
		int dataArr[] = new int[500000];
		int cArray = 0;
		
		//This for-ever loop checks if there is a token, then store that token in a data array, and add 1 to ammount of numbers in the array
		//(size array)
		for(;;) {
			
			if(input.hasNextInt()) {
				
				int token = input.nextInt();
				System.out.println(token);
				dataArr[sizeArray] = token;
				sizeArray++;
				
			}else {
				
				break;
				
			}
		}
		
		System.out.println(sizeArray);
		System.out.println(Math.sqrt(sizeArray));
		int[][] testArr = new int[500][500];
		
		//Now converts the	 data array which is a 1d to a 2d array
		for(double i = 0; i < (Math.sqrt(sizeArray)); i++) {
			
			for(double j = 0; j < (Math.sqrt(sizeArray)); j++) {
				
					testArr[(int)i][(int)j] = dataArr[cArray];
					cArray++;
					System.out.println(cArray);
					
			}
		}
		
		int mapArr[][] = mapInit(testArr);
					
		for(;;) {
						
			mapArr = nextState(mapArr);
			
		}
	}
}