module afleveringsopgave1 {
}