package afleveringsopgave1;

public class UsingClassConstant {
	public static final int LINES = 3;
	
	public static void main(String[] args) {
		for (int i = 1; i <= LINES ; i++) {
			System.out.println("+-+-+-+");
		}
	}
}
 