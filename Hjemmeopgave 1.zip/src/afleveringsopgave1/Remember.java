package afleveringsopgave1;

public class Remember {
	// Function for printing the first and third line
	static void printFunc() {
		System.out.print("Use \"\\\\\"  to obtain a �backslash� character.\n");
	}
	
	public static void main(String[] args) {
		// Calling the print function twice with a System.out.print for the second line in the middle
		printFunc();
		System.out.print("Remember:\n");
		printFunc();
	}
}
